 
XML-RPC server accepts POST requests only.